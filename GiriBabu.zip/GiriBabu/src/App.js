// Imports From Node Modueles
import { HelmetProvider } from 'react-helmet-async';
import { HashRouter } from 'react-router-dom';

// Custom Imports
import './App.scss';
import NavBar from './components/NavBar/NavBar';
import Footer from './components/Footer/Footer';
import AppRoutes from './routes/AppRoutes';

function App () {
  return (
    <HelmetProvider>
      <HashRouter>
        <div className="gl-main-wrapper">
          <a href="#mainBody" className="skip-to-content">
            Skip to main content
          </a>

          {/* Header Block */}
          <NavBar />

          {/* Main block */}
          <main className="gl-main-container" id="mainBody">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <AppRoutes />
                </div>
              </div>
            </div>
          </main>

          {/* Footer Block */}
          <Footer />
        </div>
      </HashRouter>
    </HelmetProvider>
  );
}

export default App;
