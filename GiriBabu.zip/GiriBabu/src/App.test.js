import { render, screen } from '@testing-library/react';
import App from './App';

test('should have Latest Products title', () => {
  render(<App />);
  const linkElement = screen.getByText(/Latest Products/i);
  expect(linkElement).toBeInTheDocument();
});
