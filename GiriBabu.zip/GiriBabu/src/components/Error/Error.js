// When Rest API fails, it show  the below error message
const Error = () => {
  return (
    <div className="alert alert-danger" data-testid="errorMsg">
      Sorry! Some Error Occurred. Try again later!
    </div>
  );
};

export default Error;
