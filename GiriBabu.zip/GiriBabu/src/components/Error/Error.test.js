// Test Pattern AAA
// Arrange
import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';

// Custom Imports
import Error from './Error';

describe('Error', () => {
  // If Rest API fails, It should show the below error message
  it('should show error message', () => {
    render(
      <HashRouter>
        <Error />
      </HashRouter>
    );

    const errorMsg = screen.getByTestId('errorMsg');
    expect(errorMsg.textContent).toBe(
      'Sorry! Some Error Occurred. Try again later!'
    );
  });
});
