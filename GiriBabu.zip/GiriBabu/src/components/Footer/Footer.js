// Custom Imports
import MenuList from '../MenuList/MenuList';
import SocialShareIcons from './SocialShareIcons/SocialShareIcons';

const Footer = () => {
  return (
    <footer className="gl-cmp-footer footer border-top">
      <div className="container-fluid">
        <div className="row">
          <div className="col-12">
            <div className="row py-4">
              <div className="col-md-8 d-flex">
                {/* Footer Links */}
                <div className="list-unstyled footer__links">
                  <MenuList />
                </div>

                {/* Social Share Icons */}
                <ul className="list-unstyled footer__social-icons">
                  <SocialShareIcons />
                </ul>
              </div>

              {/* Copyright Text */}
              <div className="col-4">
                <p className="text-end mb-0" data-testid="copyRightText">
                  &copy; Copyright 2022 Company | MyShop
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
