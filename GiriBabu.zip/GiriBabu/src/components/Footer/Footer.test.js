// Test Pattern AAA
// Arrange
import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';

// Custom Imports
import Footer from './Footer';

describe('Footer', () => {
  it('should render with proper copy right text', () => {
    render(
      <HashRouter>
        <Footer />
      </HashRouter>
    );

    const copyRightText = screen.getByTestId('copyRightText');
    expect(copyRightText.textContent).toBe('© Copyright 2022 Company | MyShop');
  });
});
