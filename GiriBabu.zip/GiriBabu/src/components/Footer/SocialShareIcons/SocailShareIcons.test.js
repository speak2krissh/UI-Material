import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

import SocialShareIcons from './SocialShareIcons';
describe('Footer', () => {
  it('should render with proper social share icons', () => {
    render(
      <MemoryRouter>
        <SocialShareIcons />
      </MemoryRouter>
    );

    const facebookIcon = screen.getByTestId('facebook');
    const twitterIcon = screen.getByTestId('twitter');
    const instagramIcon = screen.getByTestId('instagram');
    const whatsappIcon = screen.getByTestId('whatsapp');

    expect(facebookIcon).toBeInTheDocument();
    expect(twitterIcon).toBeInTheDocument();
    expect(instagramIcon).toBeInTheDocument();
    expect(whatsappIcon).toBeInTheDocument();
  });
});
