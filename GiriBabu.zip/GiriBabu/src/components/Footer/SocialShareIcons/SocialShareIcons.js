// Imports From Node Modueles
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

// Custom Imports
import {
  faSquareFacebook,
  faSquareTwitter,
  faInstagram,
  faWhatsapp
} from '@fortawesome/free-brands-svg-icons';

const SocialShareIcons = () => {
  return (
    <>
      <li className="nav-item">
        <Link to="#" className="nav-link">
          <FontAwesomeIcon icon={faSquareFacebook} size="lg" data-testid="facebook"/>
        </Link>
      </li>

      <li className="nav-item">
        <Link to="#" className="nav-link">
          <FontAwesomeIcon icon={faSquareTwitter} size="lg" data-testid="twitter"/>
        </Link>
      </li>

      <li className="nav-item">
        <Link to="#" className="nav-link">
          <FontAwesomeIcon icon={faInstagram} size="lg" data-testid="instagram" />
        </Link>
      </li>

      <li className="nav-item">
        <Link to="#" className="nav-link">
          <FontAwesomeIcon icon={faWhatsapp} size="lg" data-testid="whatsapp" />
        </Link>
      </li>
    </>
  );
};

export default SocialShareIcons;
