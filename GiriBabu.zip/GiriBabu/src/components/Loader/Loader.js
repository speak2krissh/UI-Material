// When Rest API service is happening, It shows the spinner/loader until we get response(either success or failure)
const Loader = () => {
  return (
    <div className="spinner-border text-success" role="status" data-testid='loader'></div>
  )
}

export default Loader;
