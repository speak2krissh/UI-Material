import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';

import Loader from './Loader';

describe('Loader', () => {
  // It show the spinner until REST API service call is completed
  it('should have spinner-border class', () => {
    render(
      <HashRouter>
        <Loader />
      </HashRouter>
    );

    const className = screen.getByTestId('loader');
    expect(className).toHaveClass('spinner-border');
  });
});
