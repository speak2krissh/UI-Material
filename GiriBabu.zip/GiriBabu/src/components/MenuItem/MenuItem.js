// Imports From Node Modueles
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';

// Receive the name and path as perameter and generate the menu item
const MenuItem = ({ name, path }) => {
  return (
    <li className="nav-item" data-testid="menuItem">
      <NavLink className="nav-link" to={path} >
        {name}
      </NavLink>
    </li>
  );
};

MenuItem.propTypes = {
  name: PropTypes.string,
  path: PropTypes.string
};

export default MenuItem;
