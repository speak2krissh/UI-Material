// Test Pattern AAA
// Arrange
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

// Custom Imports
import MenuItem from './MenuItem';

describe('MenuItem', () => {
  it('should receive props and dispaly properly', () => {
    render(
      <MemoryRouter>
        <MenuItem name="HOME" path="/" />
      </MemoryRouter>
    );
    // Menu Name checking
    const menuName = screen.getByTestId('menuItem');
    expect(menuName.textContent).toBe('HOME');

    // Menu Navigation Link checking
    const homeLink = screen.getByRole('link', { name: /HOME/i });
    expect(homeLink).toHaveAttribute('href', '/');
  });
});
