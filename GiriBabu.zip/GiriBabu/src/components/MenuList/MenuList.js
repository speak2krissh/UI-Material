// Custom imports
import MenuItem from '../MenuItem/MenuItem';
import { menuItems } from '../../data/menu';

const MenuList = () => {
  return (
    <ul className='list-unstyled navbar-nav me-4' data-testid="menuList">
      {menuItems.map((menu) => (
        <MenuItem {...menu} key={menu.id} />
      ))}
    </ul>
  );
};

export default MenuList;
