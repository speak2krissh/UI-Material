// Test Pattern AAA
// Arrange
import { render } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';

// Custom Imports
import MenuList from './MenuList';

describe('MenuList', () => {
  it('Renders with a className equal to the navbar-nav', () => {
    const { container } = render(
      <HashRouter>
        <MenuList />
      </HashRouter>
    );

    expect(container.firstChild).toHaveClass('navbar-nav');
  });
});
