// Imports from Node Modules
import { Link } from 'react-router-dom';

// Custom Imports
import MenuList from '../MenuList/MenuList';

const NavBar = () => {
  return (
    <header className="gl-cmp-header">
      <nav className="navbar navbar-expand-lg" data-testid="navBar">
        <div className="container-fluid">
          {/* Logo */}
          <Link className="navbar-brand" to="/">
            <img
              src="../assets/images/logo.jpg"
              className="img-fluid"
              alt="Logo"
            />
          </Link>

          {/* Hamburger Menu Icon */}
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>

          {/* Primary Navigation */}
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <form className="search me-4">
              <input
                className="form-control me-2"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
            </form>

            {/* Primary Navigation */}
            <MenuList />

            <button className="btn btn-danger" type="button">
              cart(0)
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default NavBar;
