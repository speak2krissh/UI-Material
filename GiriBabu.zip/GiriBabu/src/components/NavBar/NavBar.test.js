// Test Pattern AAA
// Arrange
import { render } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';

// Custom Imports
import NavBar from './NavBar';

describe('NavBar', () => {
  it('Renders with a className equal to the gl-cmp-header', () => {
    const { container } = render(
      <HashRouter>
        <NavBar />
      </HashRouter>
    );

    expect(container.firstChild).toHaveClass('gl-cmp-header');
  });

  it('displays a logo', () => {
    render(
      <HashRouter>
        <NavBar />
      </HashRouter>
    );

    const displayedLogo = document.querySelector('img');
    expect(displayedLogo.src).toContain('logo.jpg');
  });
});
