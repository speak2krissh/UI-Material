// Imports from Node Modules
import { PropTypes } from 'prop-types';
import { Link } from 'react-router-dom';

const Products = ({
  id,
  name,
  thumbnailUrl,
  imgAltText,
  maxRetailPrice,
  discountApplicable
}) => {
  return (
    <div className="col-md-4 mb-4">
      <div className="card">
        <div className="card-img">
          <img src={thumbnailUrl} className="card-img-top" alt={imgAltText} />
        </div>
        <div className="card-body">
          <Link
            type="button"
            to={`/products/${id} `}
            className="product-img-wrapper"
          >
            <h5 className="card-title">{name}</h5>
          </Link>

          {/* Product Price */}
          <div className="product-price">
            Actual Price: RS{' '}
            <b className="text-decoration-line-through">{maxRetailPrice}</b>
            <b className="gl-text-green">
              {' '}
              {discountApplicable}
              {'%'}
            </b>{' '}
            off
          </div>

          {/* Product Price After Discount */}
          <div className="product-disc-price">
            After Discount Price: RS{' '}
            <b>
              {(
                maxRetailPrice -
                maxRetailPrice * (discountApplicable / 100)
              ).toFixed(2)}
            </b>
          </div>
        </div>
        <div className="card-footer text-center">
          <button className="gl-btn">Add To Cart</button>
        </div>
      </div>
    </div>
  );
};

Products.propTypes = {
  name: PropTypes.string,
  id: PropTypes.number,
  thumbnailUrl: PropTypes.string,
  imgAltText: PropTypes.string,
  maxRetailPrice: PropTypes.number,
  discountApplicable: PropTypes.number
};

export default Products;
