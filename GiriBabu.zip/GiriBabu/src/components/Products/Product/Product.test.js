import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Product from './Product';
describe('Product', () => {
  test('Renders All the Props in product Component', () => {
    const id = 1;
    const name = 'TShirt';
    const thumbnailUrl = '../images/test.png';
    const imgAltText = 'TShirt';
    const maxRetailPrice = 50000;

    render(
      <MemoryRouter>
        <Product
          id={id}
          maxRetailPrice={maxRetailPrice}
          imgAltText={imgAltText}
          thumbnailUrl={thumbnailUrl}
          name={name}
        />
      </MemoryRouter>
    );

    // Checking the Product Name
    const productName = screen.getByText('TShirt');
    expect(productName).toBeInTheDocument();

    // Checking the Max Retail Price
    const Price = screen.getByText('50000');
    expect(Price).toBeInTheDocument();

    // Checking the Product Image
    const productImage = document.querySelector('img');
    expect(productImage.src).toContain('test.png');

    // Checking the Product Image alt text
    expect(productImage.alt).toContain('TShirt');
  });
});
