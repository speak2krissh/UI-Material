// Imports from Node Modules
import { PropTypes } from 'prop-types';

// Custom Imports
import Product from './Product/Product';

// Receive Product List as prop and sent Product to Product component
const Products = ({ productsList }) => {
  return (
    <div className="row products-list" data-testid="products">
      {productsList.map((productItem) => (
        <Product key={productItem.id} {...productItem} />
      ))}
    </div>
  );
};

Products.propTypes = {
  productsList: PropTypes.array
};

export default Products;
