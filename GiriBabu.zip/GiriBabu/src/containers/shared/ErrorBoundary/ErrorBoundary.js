import React, { Component } from 'react';
import PropTypes from 'prop-types';

export default class ErrorBoundary extends Component {
  state = {
    hasError: false
  };

  static getDerivedStateFromError () {
    return {
      hasError: true
    };
  }

  // This method is called if any error is encountered
  componentDidCatch () {

  }

  render () {
    if (this.state.hasError) {
      return (
        <div className="container p-4" data-testid="errorboundary">
          <div className="alert alert-danger spark-shadow rounded-0">
            <p className="fs-5 mb-0">
              Some Error Occurred !!! Try again later{' '}
            </p>
            <p className="fs-5 mb-0">
              If the Error persists, Contact the Admin !
            </p>
          </div>
        </div>
      );
    } else {
      return this.props.children;
    }
  }
}

ErrorBoundary.propTypes = {
  children: PropTypes.any
};
