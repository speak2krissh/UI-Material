export const carouselList = [
  {
    id: 1,
    title: 'Same Day Delivery',
    desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
    btnTxt: 'Browse 100+ Products',
    imageUrl: '../assets/images/carousel/img-1.jpg',
    imgAltTxt: 'Same Day Delivery'
  },
  {
    id: 2,
    title: 'Same Day Delivery1',
    desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
    btnTxt: 'Browse 100+ Products',
    imageUrl: '../assets/images/carousel/img-2.jpg',
    imgAltTxt: 'Same Day Delivery'
  },
  {
    id: 3,
    title: 'Same Day Delivery2',
    desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
    btnTxt: 'Browse 100+ Products',
    imageUrl: '../assets/images/carousel/img-3.jpg',
    imgAltTxt: 'Same Day Delivery'
  }
];
