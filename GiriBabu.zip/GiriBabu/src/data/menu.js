export const menuItems = [
  {
    name: 'HOME',
    path: '/',
    id: 1
  },
  {
    name: 'PRODUCTS',
    path: '/products',
    id: 2
  },
  {
    name: 'ABOUT US',
    path: '/about-us',
    id: 3
  },
  {
    name: 'CONTACT',
    path: '/contact',
    id: 4
  }
];
