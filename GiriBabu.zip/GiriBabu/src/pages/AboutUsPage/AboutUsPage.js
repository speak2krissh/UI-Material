// Imports from Node Modules
import { Link, Outlet } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';

const AboutUsPage = () => {
  return (
    <>
      {/* Page Title and Description */}
      <Helmet>
        <title>About US Page Implementation</title>
        <meta
          name="description"
          content="Design a page to provide information about the Clothing Shop"
        />
      </Helmet>

      {/* About us page description */}
      <>
        <p className="mt-5">
          &ldquo;We have the capabilities and experience to deliver the products
          you need to move forward.&ldquo;
        </p>
        <p className="mb-5">
          Spark clothing is guided by four principles: customer obsession rather
          than competitor focus, passion for invention, commitment to
          operational excellence, and long-term thinking. Spark clothing strives
          to be Earth’s most customer-centric company, Earth’s best employer,
          and Earth’s safest place to work. Customer reviews, 1-Click shopping,
          personalized recommendations, Prime, Fulfillment by Spark clothing,
          AWS, Kindle Direct Publishing, Kindle, Career Choice, Fire tablets,
          Fire TV, Spark clothing Echo, Alexa, Just Walk Out technology, Spark
          clothing Studios, and The Climate Pledge are some of the things
          pioneered by Spark clothing.
        </p>

        {/* History Page Link */}
        <Link
          to="/about-us/history"
          className="gl-green d-block mb-5 text-uppercase"
        >
          The History
        </Link>
        <Outlet />
      </>
    </>
  );
};

export default AboutUsPage;
