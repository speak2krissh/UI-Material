import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import renderer from 'react-test-renderer';

// Custom Imports
import AboutUsPage from './AboutUsPage';

describe('About Us Page', () => {
  // Testing About us page
  it('should have The History content', () => {
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/about-us/history']}>
          <AboutUsPage />
        </MemoryRouter>
      </HelmetProvider>
    );
    const aboutUsElement = screen.getByText(/The History/i);
    expect(aboutUsElement).toBeInTheDocument();
  });

  // Testing the history link
  it('render link with correct attribute', () => {
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/history']}>
          <AboutUsPage />
        </MemoryRouter>
      </HelmetProvider>
    );
    const linkElement = screen.getByText(/The History/i);
    expect(linkElement).toHaveAttribute('href', '/about-us/history');
  });

  // Snapshot
  it('has right snapshot for About Us Page', () => {
    const snapshotInJson = renderer
      .create(
        <HelmetProvider>
          <MemoryRouter>
            <AboutUsPage />
          </MemoryRouter>
        </HelmetProvider>
      )
      .toJSON();

    expect(snapshotInJson).toMatchSnapshot();
  });
});
