import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

// Custom Imports
import History from './History';

describe('History', () => {
  render(
    <MemoryRouter>
      <History />
    </MemoryRouter>
  );
  it('should render History Page', () => {
    expect(History).toBeTruthy();
  });
});
