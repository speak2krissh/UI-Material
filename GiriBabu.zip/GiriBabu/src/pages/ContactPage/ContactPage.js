// Imports from Node Modules
import { useState, useEffect } from 'react';
import axios from 'axios';
import { useForm } from 'react-hook-form';
import { Helmet } from 'react-helmet-async';

// Custom Imports
import getBaseurl from './../../utilities/getBaseUrl';
import Error from '../../components/Error/Error';
import Loader from '../../components/Loader/Loader';

const ContactPage = () => {
  // Should show loader
  // Should display success message
  // Should display error message
  const [contactList, setContactList] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isError, setIsError] = useState(false);
  const [formStatus, setFormStatus] = useState({
    message: '',
    errorType: ''
  });
  const {
    register,
    formState: { errors },
    handleSubmit
  } = useForm();

  useEffect(() => {
    // Let's hit the REST API
    // REST API URL? http://localhost:3000/contactData
    // Http Method GET
    // REST API client? axios
    axios
      .get(getBaseurl() + 'contactData')
      .then((response) => {
        setContactList(response.data);
        setIsLoaded(true);
      })
      .catch(() => {
        setIsError(true);
        setIsLoaded(true);
      })
      .finally(() => {});
  }, []);

  // Submitting the Contact Form
  const onSubmit = (data, e) => {
    const { name, email, message } = data;

    axios
      .post(getBaseurl() + 'getInTouchData', {
        id: Math.floor(Math.random() * 100000),
        name,
        email,
        message
      })
      .then((response) => {
        setFormStatus({
          message: 'Form Submitted successfully',
          errorType: 'success'
        });
        e.target.reset();
      })
      .catch(() => {
        setFormStatus({
          message: 'Something went wrong. Please try again after sometime',
          errorType: 'error'
        });
      })
      .finally(() => {});
  };

  return (
    <>
      {/* Page Title and Description */}
      <Helmet>
        <title>Contact US Page Implementation</title>
        <meta
          name="description"
          content="Design a page to provide information about the Contact Details"
        />
      </Helmet>

      <div className="container-fluid mt-5 mb-5 contact-us">
        <div className="row">
          {/* Contact Details */}
          <div className="col-md-6 pb-5">
            {/* Contact Page Title */}
            <h2
              className="font-bold gl-text-green pb-3"
              data-testid="contactTitle"
            >
              Contact Us
            </h2>

            {/* Contact Page Description */}
            <p>
              If you have any questions or concerns about our services that
              require urgent intervention, you can get in touch with us in the
              following ways. Share a mail on contact@sparkclothing.com Email ID
            </p>

            {/* Loading the Loader while fetching the Contact Data */}
            {!isLoaded && <Loader />}

            {/* API service call error message */}
            {isError && <Error />}

            {/* Contact details */}
            {isLoaded && !isError && (
              <ul className="gl-unorder-list">
                <li className="pb-3">
                  <strong className="gl-text-green">Address:</strong>{' '}
                  {contactList.address}
                </li>
                <li className="pb-3">
                  <strong className="gl-text-green">Phone:</strong>{' '}
                  {contactList.phone}
                </li>
                <li className="pb-3">
                  <strong className="gl-text-green">Email:</strong>{' '}
                  {contactList.email}
                </li>
              </ul>
            )}
          </div>

          {/* Contact Form */}
          <div className="col-md-6">
            {/* Success Message */}
            {formStatus.errorType === 'success' && (
              <p className="alert alert-success">
                {formStatus.message && formStatus.message}
              </p>
            )}

            {/* Error Message */}
            {formStatus.errorType === 'error' && (
              <p className="alert alert-danger">
                {formStatus.message && formStatus.message}
              </p>
            )}

            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="input-wrapper">
                <span>Name</span>
                <input
                  {...register('name', { required: true })}
                  className="gl-form-input"
                />
                {errors.name?.type === 'required' && (
                  <p role="alert">First name is required</p>
                )}
              </div>

              <div className="input-wrapper">
                <span>Email</span>

                <input
                  {...register('email', {
                    required: 'Email Address is required',
                    pattern: {
                      value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                      message: 'Invalid email address'
                    }
                  })}
                  aria-invalid={errors.email ? 'true' : 'false'}
                  className="gl-form-input"
                />
                {errors.email && <p role="alert">{errors.email?.message}</p>}
              </div>

              <div className="input-wrapper">
                <span>Phone</span>

                <input
                  {...register('phone', { required: 'Phone Number is required' })}
                  aria-invalid={errors.phone ? 'true' : 'false'}
                  className="gl-form-input"
                />
                {errors.phone && (
                  <p role="alert">{errors.phone?.message}</p>
                )}
              </div>
              <button type="submit" className="gl-btn-submit">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContactPage;
