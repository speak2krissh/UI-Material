import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

import { HelmetProvider } from 'react-helmet-async';
import ContactPage from './ContactPage';
import axios from 'axios';

// setting up mock for axios
// mocking a module with automocked version when needed
jest.mock('axios');

// This will clear the logs from previous
beforeEach(() => {
  axios.get.mockReset();
});
describe('Contact Page', () => {
  it('[MOCKING]: Fetches contact data ', async () => {
    // 1. prepare mock response
    const mockResponse = {
      data: {
        address:
          'BLOCK D1, Manayata Embassy Business Park, Thanisandra, Bengaluru',
        phone: ['(91) 123 456 7891'],
        email: 'contact@sparkclothing.com'
      }
    };

    axios.get.mockResolvedValue(mockResponse);

    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/contact']}>
          <ContactPage />
        </MemoryRouter>
      </HelmetProvider>
    );

    const addressElement = await screen.findByText(
      'BLOCK D1, Manayata Embassy Business Park, Thanisandra, Bengaluru'
    );
    expect(addressElement).toBeInTheDocument();
  });

  // NEGATIVE TEST SPEC == Mocking ERROR Response
  it('[MOCKING]: renders error properly when REST API returns error', async () => {
    const error = 'Sorry! Some Error Occurred. Try again later!';

    axios.get.mockRejectedValue(error);

    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/contact']}>
          <ContactPage />
        </MemoryRouter>
      </HelmetProvider>
    );

    const errorElement = await screen.findByText(
      'Sorry! Some Error Occurred. Try again later!'
    );
    expect(errorElement).toBeInTheDocument();
  });

  it('has proper contact form with name, email, message field &  submit button', () => {
    // 1. prepare mock response
    const mockResponse = {
      data: {
        address:
          'BLOCK D1, Manayata Embassy Business Park, Thanisandra, Bengaluru',
        phone: ['(91) 123 456 7891'],
        email: 'contact@sparkclothing.com'
      }
    };

    axios.get.mockResolvedValue(mockResponse);

    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/contact']}>
          <ContactPage />
        </MemoryRouter>
      </HelmetProvider>
    );

    const nameInput = screen.getByText('Name');
    const emailInput = screen.getByText('Email');
    const phoneInput = screen.getByText('Phone');
    const submitBtn = screen.getByRole('button');

    expect(nameInput).toBeInTheDocument();
    expect(emailInput).toBeInTheDocument();
    expect(phoneInput).toBeInTheDocument();
    expect(submitBtn).toBeInTheDocument();
  });
});
