// Custom Imports
import CarouselItem from './CarouselItem/CarouselItem';
import { carouselList } from '../../../data/carousel';

const Carousel = () => {
  return (
    <div className="cmp-carousel">
      <div
        id="carouselExampleControlsNoTouching"
        className="carousel slide"
        data-bs-touch="false"
        data-bs-interval="false"
        data-testid="carouselWrapper"
      >
        {/* Carousel Items Block */}
        <div className="carousel-inner">
          {carouselList.map((carouselItem, index) => (
            <CarouselItem
              key={carouselItem.id}
              index={index}
              {...carouselItem}
            />
          ))}
        </div>

        {/* Carousel Control Prev Icon */}
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleControlsNoTouching"
          data-bs-slide="prev"
        >
          <span
            className="carousel-control-prev-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Previous</span>
        </button>

        {/* Carousel Control Next Icon */}
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleControlsNoTouching"
          data-bs-slide="next"
        >
          <span
            className="carousel-control-next-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  );
};

export default Carousel;
