import { render } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';

// Custom Imports
import Carousel from './Carousel';

describe('Carousel', () => {
  it('Renders with a className equal to the cmp-carousel', () => {
    const { container } = render(
      <HashRouter>
        <Carousel />
      </HashRouter>
    );

    expect(container.firstChild).toHaveClass('cmp-carousel');
  });
});
