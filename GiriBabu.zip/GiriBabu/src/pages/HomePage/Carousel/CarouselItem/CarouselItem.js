// Imports From Node Modules
import { PropTypes } from 'prop-types';

const CarouselItem = ({ title, desc, btnTxt, imageUrl, imgAltTxt, index }) => {
  return (
    <div
      className={index === 0 ? 'carousel-item active' : 'carousel-item'}
      data-testid="carouselItem"
    >
      <div className="row">
        {/* Carousel Image */}
        <div className="col-md-6">
          <div className="img-block">
            <img
              src={imageUrl}
              className="img-fluid"
              alt={imgAltTxt}
              role="img"
            />
          </div>
        </div>

        {/* Carousel Title and Description */}
        <div className="col-md-6">
          <div className="carousel-desc text-center">
            <h2>{title}</h2>
            <p>{desc}</p>
            <button className="gl-btn">{btnTxt}</button>
          </div>
        </div>
      </div>
    </div>
  );
};

CarouselItem.propTypes = {
  title: PropTypes.string,
  desc: PropTypes.string,
  imageUrl: PropTypes.string,
  btnTxt: PropTypes.string,
  index: PropTypes.number,
  imgAltTxt: PropTypes.string
};

export default CarouselItem;
