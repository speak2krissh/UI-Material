// Test Pattern AAA
// Arrange
import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';

// Custom Imports
import CarouselItem from './CarouselItem';

describe('CarouselItem', () => {
  // Testing First Carousel Item
  it('should receive Carousel Item as props and dispaly properly', () => {
    const item = {
      id: 1,
      title: 'Same Day Delivery',
      desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      btnTxt: 'Browse 100+ Products',
      imageUrl: '../assets/images/carousel/img-1.jpg',
      imgAltTxt: 'Same Day Delivery',
      index: 0
    };

    const { container } = render(
      <HashRouter>
        <CarouselItem {...item} />
      </HashRouter>
    );

    // Carousel should have active class
    expect(container.firstChild).toHaveClass('carousel-item active');

    // Testing the Image
    const carouselImage = document.querySelector('img');
    expect(carouselImage.src).toContain('img-1.jpg');

    // Testing the Heading
    const heading = screen.getByText(item.title);
    expect(heading).toBeInTheDocument();

    // Testing the Description
    const description = screen.getByText(item.desc);
    expect(description).toBeInTheDocument();

    // Testing the btnTxt
    const btnTxt = screen.getByText(item.btnTxt);
    expect(btnTxt).toBeInTheDocument();
  });

  // Testing Second Carousel Item
  it('should receive Carousel Item as props and dispaly properly', () => {
    const item = {
      id: 1,
      title: 'Same Day Delivery',
      desc: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      btnTxt: 'Browse 100+ Products',
      imageUrl: '../assets/images/carousel/img-2.jpg',
      imgAltTxt: 'Same Day Delivery',
      index: 1
    };

    const { container } = render(
      <HashRouter>
        <CarouselItem {...item} />
      </HashRouter>
    );

    // Carousel should have active class
    expect(container.firstChild).toHaveClass('carousel-item');

    // Testing the Image
    const carouselImage = document.querySelector('img');
    expect(carouselImage.src).toContain('img-2.jpg');

    // Testing the Heading
    const heading = screen.getByText(item.title);
    expect(heading).toBeInTheDocument();

    // Testing the Description
    const description = screen.getByText(item.desc);
    expect(description).toBeInTheDocument();

    // Testing the btnTxt
    const btnTxt = screen.getByText(item.btnTxt);
    expect(btnTxt).toBeInTheDocument();
  });
});
