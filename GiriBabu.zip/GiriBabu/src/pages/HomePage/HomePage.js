// Imports from Node Modules
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';

// Custom Imports
import Carousel from './Carousel/Carousel';
import Promises from './Promises/Promises';
import Error from '../../components/Error/Error';
import Loader from '../../components/Loader/Loader';
import getBaseurl from './../../utilities/getBaseUrl';
import Products from '../../components/Products/Products';

const HomePage = () => {
  // Should show loader
  // Should display success message
  // Should display error message
  const [productsList, setProductsList] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    // Let's hit the REST API
    // REST API URL? http://localhost:3000/products
    // Http Method GET
    // REST API client? axios
    axios
      .get(getBaseurl() + 'products?_limit=3')
      .then((response) => {
        setProductsList(response.data);
        setIsLoaded(true);
      })
      .catch(() => {
        setIsError(true);
        setIsLoaded(true);
      })
      .finally(() => {});
  }, []);

  return (
    <>
      {/* Page Title and Description */}
      <Helmet>
        <title>Home Page Implementation</title>
        <meta
          name="description"
          content="Design a page as given in the expected output. Logo and designs are customisable"
        />
      </Helmet>

      {/* Carousel component */}
      <Carousel />

      {/* Latest Products */}
      <div className="latest-products">
        <h2 className="gl-text-blue mb-4">Latest Products</h2>

        {!isLoaded && <Loader />}
        {isError && <Error />}
        {isLoaded && <Products productsList={productsList} />}
        <div className="view-all text-center mt-5">
          <Link to="/products" className="gl-link">
            View All
          </Link>
        </div>
      </div>

      {/* Promises */}
      <Promises />
    </>
  );
};

export default HomePage;
