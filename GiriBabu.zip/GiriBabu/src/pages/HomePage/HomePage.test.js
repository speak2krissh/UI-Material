import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import axios from 'axios';

// Custom Imports
import HomePage from './HomePage';

jest.mock('axios');

describe('Home', () => {
  it('should have Latest Products content', async () => {
    const mockResponse = {
      data: [
        {
          id: 1,
          name: 'My name is what',
          description:
            'GLORYBOYZ Mens Floral Printed Wedding Party Button Down Casual Shirts. Lorem Ipsum is simply dummy text of the printing and ypesetting industry. Lorem Ipsum has been the industrys tandard dummy text ever since the 1500s, when n unknown rinter took a galley of type and scrambled it to make a ype specimen book.',
          imageUrl: '../assets/images/products/01-male.jpg',
          thumbnailUrl: '../assets/images/products/01-male.jpg',
          imgAltText: 'GLORYBOYZ',
          maxRetailPrice: 1197,
          category: 'Men',
          discountApplicable: 14,
          added: '5/6/2023',
          quantity: 8,
          bestSellerRanking: 3,
          featured: true,
          reviews: [
            {
              id: 96964,
              name: 'Shan',
              email: 'test@yopmail.com',
              rating: '4',
              comment: 'Gopal Comment',
              phone: '5'
            }
          ]
        },
        {
          id: 2,
          name: 'SOURBH',
          description:
            "SOURBH Women's Cotton Sequins Embroidery Work Foil Printed A-Line Kurti Only Lorem Ipsum is simply dummy text of the printing and ypesetting industry. Lorem Ipsum has been the industrys tandard dummy text ever since the 1500s, when n unknown rinter took a galley of type and scrambled it to make a ype specimen book.",
          imageUrl: '../assets/images/products/02-female.jpg',
          thumbnailUrl: '../assets/images/products/02-female.jpg',
          imgAltText: 'SOURBH',
          maxRetailPrice: 1299,
          category: 'Women',
          discountApplicable: 14,
          added: '14/3/2023',
          quantity: 6,
          bestSellerRanking: 1,
          featured: true,
          reviews: [
            {
              id: 66178,
              name: 'GiriBabu',
              email: 'test@gmail.com',
              rating: '4',
              comment: 'test',
              phone: '456789544'
            },
            {
              id: 25197,
              name: 'GiriBabu',
              email: 'test123@gmail.com',
              phone: '3473957349',
              review: 'sd s saf a',
              rating: 5
            },
            {
              id: 54249,
              name: 'GiriBabu123',
              email: 'test4567@gmail.com',
              phone: '3473957349',
              review: 'df sdf sf s',
              rating: 5
            },
            {
              id: 43789,
              name: 'GiriBabu005',
              email: 'test8976@gmail.com',
              phone: '3473957349',
              review: 'fd sd sfasf',
              rating: 5
            },
            {
              id: 42387,
              name: 'GiriBabu123',
              email: 'VenkataGiriBabu.Karibandi@gilead.com',
              phone: '3473957349',
              review: 'fdfgdfg dg',
              rating: 5
            },
            {
              id: 52334,
              name: 'GiriBabu009877',
              email: 'test00006789@gmail.com',
              phone: '3473957349',
              review: 'fgdfgdfgd',
              rating: 5
            }
          ]
        },
        {
          id: 3,
          name: 'Abc',
          description:
            'Fanideaz Mens Cotton Half Sleeve Solid Polo T Shirt with Collar Lorem Ipsum is simply dummy text of the printing and ypesetting industry. Lorem Ipsum has been the industrys tandard dummy text ever since the 1500s, when n unknown rinter took a galley of type and scrambled it to make a ype specimen book.',
          imageUrl: '../assets/images/products/03-male.jpg',
          thumbnailUrl: '../assets/images/products/03-male.jpg',
          imgAltText: 'Fanideaz',
          maxRetailPrice: 1599,
          category: 'Men',
          discountApplicable: 14,
          added: '29/6/2023',
          quantity: 2,
          bestSellerRanking: 1,
          featured: true,
          reviews: [
            {
              id: 1002,
              name: 'Krissh',
              email: 'speak2krissh@gmail.com',
              phone: '7416639544',
              comment: 'Very Good!',
              rating: 4
            }
          ],
          msg: 'awesome'
        }
      ]
    };

    axios.get.mockResolvedValue(mockResponse);

    render(
      <HelmetProvider>
        <HashRouter>
          <HomePage />
        </HashRouter>
      </HelmetProvider>
    );

    const carouselTitle = screen.getByText('Latest Products');
    expect(carouselTitle).toBeInTheDocument();
  });

  // NEGATIVE TEST SPEC == Mocking ERROR Response
  it('[MOCKING]: renders error properly when REST API returns error', async () => {
    const error = 'Sorry! Some Error Occurred. Try again later!';

    axios.get.mockRejectedValue(error);

    render(
      <HelmetProvider>
        <HashRouter>
          <HomePage />
        </HashRouter>
      </HelmetProvider>
    );

    const errorElement = await screen.findByText(
      'Sorry! Some Error Occurred. Try again later!'
    );
    expect(errorElement).toBeInTheDocument();
  });
});
