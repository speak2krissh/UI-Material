// Imports From Node Modules
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faTruckFast,
  faHandHoldingDollar
} from '@fortawesome/free-solid-svg-icons';

const Promises = () => {
  return (
    <div className="promises">
      <div className="row gl-features mt-5 mb-5" data-testid="promisesWrapper">
        <div className="col-md-4">
          <div className="row align-items-center">
            <div className="col-2">
              <FontAwesomeIcon
                icon={faTruckFast}
                className="feature-icon fa-2x"
                data-testid="truckFast1"
              />
            </div>

            <div className="col-10">
              <div className="feature-content">
                <h5 className="mb-0 title">FREE SHIPPING & RETURN</h5>
                <p className="mb-0">Free shipping on orders above Rs.499</p>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="row align-items-center">
            <div className="col-2">
              <FontAwesomeIcon
                icon={faHandHoldingDollar}
                className="feature-icon fa-2x" data-testid="handHoldingDollar"
              />
            </div>

            <div className="col-10">
              <div className="feature-content">
                <h5 className="mb-0 title">MONEY BACK GUARANTEE</h5>
                <p className="mb-0">100% money back guarantee.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="row align-items-center">
            <div className="col-2">
              <FontAwesomeIcon
                icon={faTruckFast}
                className="feature-icon fa-2x"
                data-testid="truckFast2"
              />
            </div>

            <div className="col-10">
              <div className="feature-content">
                <h5 className="mb-0 title">ONLINE SUPPORT 24/7</h5>
                <p className="mb-0">Reach out us at anytime.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Promises;
