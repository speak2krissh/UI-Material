import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import Promises from './Promises';

describe('Promises', () => {
  it('should have List of 3 Promises', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const promisesWrapper = screen.getByTestId('promisesWrapper');
    const promises = promisesWrapper.querySelectorAll('.col-md-4');
    expect(promises.length).toBe(3);
  });

  // FREE SHIPPING & RETURN Promises related test cases
  it('should should have title FREE SHIPPING & RETURN', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const heading = screen.getByText('FREE SHIPPING & RETURN');
    expect(heading).toBeInTheDocument();
  });

  it('should should have description Free shipping on orders above Rs.499', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const description = screen.getByText(
      'Free shipping on orders above Rs.499'
    );
    expect(description).toBeInTheDocument();
  });

  it('should should have proper icon', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const truckFastIcon = screen.getByTestId('truckFast1');
    expect(truckFastIcon).toBeInTheDocument();
  });

  // MONEY BACK GUARANTEE Promises related test cases
  it('should should have title MONEY BACK GUARANTEE', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const heading = screen.getByText('MONEY BACK GUARANTEE');
    expect(heading).toBeInTheDocument();
  });

  it('should should have description 100% money back guarantee.', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const description = screen.getByText('100% money back guarantee.');
    expect(description).toBeInTheDocument();
  });

  it('should should have proper icon', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const handHoldingDollarIcon = screen.getByTestId('handHoldingDollar');
    expect(handHoldingDollarIcon).toBeInTheDocument();
  });

  // ONLINE SUPPORT 24/7 Promises related test cases
  it('should should have title ONLINE SUPPORT 24/7', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const heading = screen.getByText('ONLINE SUPPORT 24/7');
    expect(heading).toBeInTheDocument();
  });

  it('should should have description Reach out us at anytime.', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const description = screen.getByText('Reach out us at anytime.');
    expect(description).toBeInTheDocument();
  });

  it('should should have proper icon', () => {
    render(
      <HashRouter>
        <Promises />
      </HashRouter>
    );

    const truckFast2 = screen.getByTestId('truckFast1');
    expect(truckFast2).toBeInTheDocument();
  });
});
