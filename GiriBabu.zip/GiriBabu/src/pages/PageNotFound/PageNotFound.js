// Imports from Node Modules
import { Link } from 'react-router-dom';

const PageNotFound = () => {
  return (
    <>

      <div className="text-center" data-testid="pageNotFound">
        <h3 className="mt-4 mb-4">Page Not Found</h3>
        <Link to="/">Visit Home Page</Link>
      </div>
    </>
  );
};

export default PageNotFound;
