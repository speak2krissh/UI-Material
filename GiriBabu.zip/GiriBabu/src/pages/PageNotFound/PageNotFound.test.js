// Test Pattern AAA
// Arrange
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

import PageNotFound from './PageNotFound';

describe('PageNotFound', () => {
  it('should render Page Not Found Content', () => {
    render(
      <MemoryRouter>
        <PageNotFound />
      </MemoryRouter>
    );
    const pageNotFoundContent = screen.getByText(/Page Not Found/i);
    expect(pageNotFoundContent).toBeInTheDocument();
  });

  it('should have proper home page link', () => {
    render(
      <MemoryRouter>
        <PageNotFound />
      </MemoryRouter>
    );
    const homeLink = screen.getByRole('link', { name: /Visit Home Page/i });
    expect(homeLink).toHaveAttribute('href', '/');
  });
});
