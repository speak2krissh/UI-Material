// import { useSearchParams } from 'react-router-dom';
import React from 'react';
import { PropTypes } from 'prop-types';
import { useSearchParams } from 'react-router-dom';

const PriceFilter = ({ selectedValue, setSelectedValue, setPriceSorting }) => {
  const [searchParam, setSearchParam] = useSearchParams();
  const priceSorting = [
    {
      id: 1,
      key: 'asc',
      value: 'Price - Low to High'
    },
    { id: 2, key: 'desc', value: 'Price - High to Low' }
  ];

  // Handing the price filter functionality
  const handlePriceSorting = (event) => {
    // Updating the selected value, if selected value is empty, we are displaying products without sorting order
    setSelectedValue(event.target.value);

    // Updating the price order, basing on this update we are filtering the products
    setPriceSorting('_sort=maxRetailPrice&_order=' + event.target.value);

    // updating the browser url on price shorting.
    const categoryVal = searchParam.get('category');
    categoryVal !== null
      ? setSearchParam({
        category: categoryVal,
        sort: 'maxRetailPrice',
        order: event.target.value
      })
      : setSearchParam({
        sort: 'maxRetailPrice',
        order: event.target.value
      });
  };
  return (
    <>
      <label
        className="text-white text-shadow d-md-inline fw-5 fs-5 me-2"
        data-testid="sortByText"
      >
        Sort By
      </label>
      <select
        name="sortingPrice"
        className="form-select spark-select"
        aria-label="filter price"
        onChange={handlePriceSorting}
        value={selectedValue}
      >
        <option value="">Select Filter</option>
        {/* <option value="asc">Price - Low to High</option>
        <option value="desc">Price - High to Low</option> */}
        {priceSorting &&
          priceSorting.map((option) => {
            return (
              <option key={option.id} value={option.key}>
                {option.value}
              </option>
            );
          })}
      </select>
    </>
  );
};

PriceFilter.propTypes = {
  setSelectedValue: PropTypes.func,
  setPriceSorting: PropTypes.func,
  selectedValue: PropTypes.string
};

export default PriceFilter;
