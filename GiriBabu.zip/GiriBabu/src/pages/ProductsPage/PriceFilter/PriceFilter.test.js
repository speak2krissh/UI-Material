// Test Pattern AAA
// Arrange
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

import PriceFilter from './PriceFilter';

describe('Footer', () => {
  it('should render List of 4 menu items', () => {
    render(
      <MemoryRouter>
        <PriceFilter />
      </MemoryRouter>
    );
    const sortByText = screen.getByText(/Sort By/i);
    expect(sortByText).toBeInTheDocument();
  });
});
