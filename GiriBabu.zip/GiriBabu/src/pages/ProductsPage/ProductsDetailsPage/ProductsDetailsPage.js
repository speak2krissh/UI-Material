// Imports from the Node Modules
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import ReactStars from 'react-rating-stars-component';
import { useForm } from 'react-hook-form';

// Custom Imports
import ReviewComments from './ReviewComments/ReviewComments';
import getBaseurl from './../../../utilities/getBaseUrl';
import Error from './../../../components/Error/Error';
import Loader from './../../../components/Loader/Loader';

const ProductsDetailsPage = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  // should display success response
  const [product, setProduct] = useState([]);
  // should display error response
  const [isError, setIsError] = useState(false);
  // Get Query Param
  const { id } = useParams();
  const [rating, setRating] = useState(4);
  const [formStatus, setFormStatus] = useState({
    message: '',
    errorType: ''
  });
  const {
    register,
    formState: { errors },
    handleSubmit
  } = useForm();

  useEffect(() => {
    // Let's hit the REST API
    // REST API URL? http://localhost:3000/products/id
    // Http Method GET
    // REST API client? axios
    axios
      .get(getBaseurl() + `products/${id}`)
      .then((res) => {
        setIsLoaded(true);
        setProduct(res.data);
      })
      .catch(() => {
        setIsLoaded(true);
        setIsError(true);
      })
      .finally(() => {});
  }, []);

  // On selecting the rating, updating the rating state value
  const handleRating = (rating) => {
    setRating(rating);
  };

  // Submiting the Review
  const onSubmit = (data, e) => {
    const { name, email, phone, review } = data;
    const isEmailExist = product.reviews.some((review) => {
      return email === review.email;
    });
    if (!isEmailExist) {
      axios
        .patch(getBaseurl() + `products/${id}`, {
          reviews: [
            ...product.reviews,
            {
              id: Math.floor(Math.random() * 100000),
              name,
              email,
              phone,
              review,
              rating
            }
          ]
        })
        .then((response) => {
          setFormStatus({
            message: 'Form Submitted successfully',
            errorType: 'success'
          });
          setProduct(response.data);
          setRating(1);
          e.target.reset();
        })
        .catch(() => {
          setFormStatus({
            message: 'Something went wrong. Please try again after sometime',
            errorType: 'error'
          });
        })
        .finally(() => {});
    } else {
      setFormStatus({
        message: 'Review is already submitted',
        errorType: 'error'
      });
    }
  };

  return (
    <div className="cotainer-fluid product-details mt-5 mb-5">
      <div className="row">
        <div className="col-12">
          <Link to="/products" className="mb-4 text-uppercase d-block">
            Back To Products Page
          </Link>
        </div>
      </div>

      <div className="row">
        {!isLoaded && <Loader />}
        {isError && <Error />}
      </div>

      {/* Product Details */}
      {isLoaded && !isError && (
        <div className="row">
          <div className="col-md-4">
            <div className="img-block">
              <div className="product-image">
                <img
                  src={product.imageUrl}
                  alt={product.imgAltText}
                  className="img-fluid"
                />
              </div>
            </div>
          </div>
          <div className="col-md-8">
            {/* Product Name */}
            <div className="product-name font-bold mb-3 fs-2" data-testid="productName">
              {product.name}
            </div>

            {/* Product Description */}
            <div className="product-description mb-3">
              {product.description}
            </div>

            {/* Product Price */}
            <div className="product-price">
              Actual Price: RS{' '}
              <b className="text-decoration-line-through">
                {product.maxRetailPrice}
              </b>
              <b className="gl-text-green">
                {' '}
                {product.discountApplicable}
                {'%'}
              </b>{' '}
              off
            </div>

            {/* Product Price After Discount */}
            <div className="product-disc-price">
              After Discount Price: RS{' '}
              <b>
                {(
                  product.maxRetailPrice -
                  product.maxRetailPrice * (product.discountApplicable / 100)
                ).toFixed(2)}
              </b>
            </div>

            {/* Product Quantity */}
            <div className="product-qty mt-3">
              <label htmlFor="qty">Qty:</label>
              <input className="qty-box" placeholder="1" id="qty" />
            </div>

            {/* Add to Cart Button */}
            <div className="add-cart-btn mt-3">
              <button className="gl-btn">Add To Cart</button>
            </div>

            {/* Reviews Section */}
            <div className="product-reviews mt-4">
              <div className="row">
                <div className="col-md-6">
                  {/* Displaying the reviews count */}
                  <p>
                    Total Reviews{': '}
                    <b>{product.reviews.length ? product.reviews.length : 0}</b>
                  </p>

                  {/* Displaying the all reviews related to product */}
                  {product.reviews.map((review) => (
                    <ReviewComments key={review.id} {...review} />
                  ))}
                </div>
                <div className="col-md-6">
                  <button
                    className="gl-btn"
                    data-testid="addReviewBtn"
                    data-bs-toggle="modal"
                    data-bs-target="#reviewModal"
                  >
                    Add Review
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Submit the rating */}
      <div
        className="modal fade"
        id="reviewModal"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="input-wrapper">
                  <span>Name</span>
                  <input
                    {...register('name', { required: true })}
                    className="gl-form-input"
                  />
                  {errors.name?.type === 'required' && (
                    <p role="alert">First name is required</p>
                  )}
                </div>

                <div className="input-wrapper">
                  <span>Email</span>
                  <input
                    {...register('email', {
                      required: 'Email Address is required',
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: 'Invalid email address'
                      }
                    })}
                    aria-invalid={errors.email ? 'true' : 'false'}
                    className="gl-form-input"
                  />
                  {errors.email && <p role="alert">{errors.email?.message}</p>}
                </div>

                <div className="input-wrapper">
                  <span>Phone</span>
                  <input
                    type="tel"
                    {...register('phone', {
                      required: 'Phone Number is required'
                    })}
                    aria-invalid={errors.phone ? 'true' : 'false'}
                    className="gl-form-input"
                  />
                  {errors.phone && <p role="alert">{errors.phone?.message}</p>}
                </div>

                <div className="input-wrapper">
                  <span>Rating</span>
                  <ReactStars
                    count={5}
                    onChange={handleRating}
                    size={24}
                    activeColor="#ffd700"
                    value={rating}
                  />
                </div>

                <div className="input-wrapper">
                  <span>Review</span>

                  <textarea
                    {...register('review', { required: true })}
                    className="gl-form-input"
                  />
                  {errors.review?.type === 'required' && (
                    <p role="alert">Review is required</p>
                  )}
                </div>

                {/* Success Message */}
                {formStatus.errorType === 'success' && (
                  <p className="alert alert-success">
                    {formStatus.message && formStatus.message}
                  </p>
                )}

                {/* Error Message */}
                {formStatus.errorType === 'error' && (
                  <p className="alert alert-danger">
                    {formStatus.message && formStatus.message}
                  </p>
                )}

                <div className="input-wrapper">
                  <button
                    type="button"
                    className="gl-btn-submit me-3"
                    data-bs-dismiss="modal"
                  >
                    Cancel
                  </button>
                  <input type="submit" className="gl-btn-submit" />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsDetailsPage;
