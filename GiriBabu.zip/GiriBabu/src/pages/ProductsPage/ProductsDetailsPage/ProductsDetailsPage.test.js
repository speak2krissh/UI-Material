import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import axios from 'axios';
import ProductsDetailsPage from './ProductsDetailsPage';
import Error from '../../../components/Error/Error';
import Loader from '../../../components/Loader/Loader';

// setting up mock for axios
// mocking a module with automocked version when needed

jest.mock('axios');

describe('Product Details Page', () => {
  // beforeEach(() => {
  //   jest.clearAllMocks();
  // });

  it('[MOCKING]: Fetches Products data ', async () => {
    const mockProducts = {
      data: [
        {
          id: 4,
          name: 'Dennis Lingo',
          description:
            "Dennis Lingo Men's Solid Slim Fit Cotton Casual Shirt with Spread Collar & Full Sleeves",
          imageUrl: '../assets/images/products/04-male.jpg',
          thumbnailUrl: '../assets/images/products/04-male.jpg',
          imgAltText: 'Dennis Lingo',
          maxRetailPrice: 1688,
          category: 'Men',
          discountApplicable: 14,
          added: '3/3/2023',
          quantity: 7,
          bestSellerRanking: 2,
          featured: true,
          reviews: [
            {
              id: 66178,
              name: 'GiriBabu',
              email: 'test@gmail.com',
              rating: 4,
              review: 'test',
              phone: '456789544'
            },
            {
              id: 25197,
              name: 'GiriBabu',
              email: 'test123@gmail.com',
              phone: '3473957349',
              review: 'sd s saf a',
              rating: 5
            },
            {
              id: 54249,
              name: 'GiriBabu123',
              email: 'test4567@gmail.com',
              phone: '3473957349',
              review: 'df sdf sf s',
              rating: 5
            }
          ]
        }
      ]
    };

    axios.get.mockResolvedValue(mockProducts);

    render(
      <HelmetProvider>
        <HashRouter>
          <ProductsDetailsPage>
            <Loader />
          </ProductsDetailsPage>
        </HashRouter>
      </HelmetProvider>
    );

    const productName = await screen.findByTestId('productName');
    expect(productName.textContent).toBe('Dennis Lingo');
  });

  // NEGATIVE TEST SPEC == Mocking ERROR Response
  it('[MOCKING]: renders error properly when REST API returns error', async () => {
    const error = 'Sorry! Some Error Occurred. Try again later!';

    axios.get.mockRejectedValue(error);

    render(
      <HelmetProvider>
        <HashRouter>
          <ProductsDetailsPage>
            <Error />
          </ProductsDetailsPage>
        </HashRouter>
      </HelmetProvider>
    );

    const errorElement = await screen.findByText(
      'Sorry! Some Error Occurred. Try again later!'
    );
    expect(errorElement).toBeInTheDocument();
  });

  // Modal Popup Events
  // it('On click Add Review modal should open', () => {
  //   <HelmetProvider>
  //     <HashRouter initialEntries={['/products/4']}>
  //       <ProductsDetailsPage>
  //         <Error />
  //       </ProductsDetailsPage>
  //     </HashRouter>
  //   </HelmetProvider>;
  //   // find the Add Review button element
  //   const addReviewBtn = screen.getByTestId('addReviewBtn');
  //   fireEvent.click(addReviewBtn);
  // });
});
