// Imports From Node Modules
import { PropTypes } from 'prop-types';

const ReviewComments = ({ name, email, review, rating }) => {
  return (
    <div className="review">
      <p className="mb-1">
        Name: <b>{name}</b>
      </p>
      <p className="mb-1">
        Comment: <b>{review}</b>
      </p>
      <p className="mb-1">
        Mail ID: <b>{email}</b>
      </p>
      <p className="mb-4">
        Rating: <b>{rating}</b>
      </p>
    </div>
  );
};

ReviewComments.propTypes = {
  name: PropTypes.string,
  email: PropTypes.string,
  review: PropTypes.string,
  rating: PropTypes.number
};

export default ReviewComments;
