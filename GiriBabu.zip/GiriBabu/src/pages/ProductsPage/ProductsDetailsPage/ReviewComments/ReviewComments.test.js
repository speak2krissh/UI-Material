import { render } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import ReviewComments from './ReviewComments';

test('Renders All the Props in Review Comments Component', () => {
  const name = 'GiriBabu';
  const email = 'giribabu@gmail.com';
  const review = 'Nice Product';
  const rating = 4;

  const { getByText } = render(
    <HashRouter>
      <ReviewComments
        name={name}
        email={email}
        comment={review}
        rating={rating}
      />
    </HashRouter>
  );

  const nameElement = getByText('GiriBabu');
  expect(nameElement).toBeInTheDocument();

  const emailElement = getByText('giribabu@gmail.com');
  expect(emailElement).toBeInTheDocument();

  const ratingElement = getByText(4);
  expect(ratingElement).toBeInTheDocument();

  const commentElement = getByText('Nice Product');
  expect(commentElement).toBeInTheDocument();
});
