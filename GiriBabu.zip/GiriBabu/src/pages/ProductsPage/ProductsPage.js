// Imports from Node Modules
import axios from 'axios';
import { useState, useEffect } from 'react';
import { useLocation } from 'react-router';
import { Helmet } from 'react-helmet-async';

// Custom Imports
import SideBar from './SideBar/SideBar';
import Error from '../../components/Error/Error';
import Loader from '../../components/Loader/Loader';
import getBaseurl from './../../utilities/getBaseUrl';
import Products from '../../components/Products/Products';
import PriceFilter from './PriceFilter/PriceFilter';

const ProductsPage = () => {
  const [productsList, setProductsList] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isError, setIsError] = useState(false);
  const queryParam = useLocation().search;
  const [priceSorting, setPriceSorting] = useState('');
  const [selectedValue, setSelectedValue] = useState('');
  let API_URL = getBaseurl() + 'products';

  if (queryParam.length) {
    if (priceSorting) {
      API_URL = API_URL + queryParam + '&' + priceSorting;
    } else {
      API_URL = API_URL + queryParam;
    }
  } else {
    if (priceSorting) {
      API_URL = API_URL + '?' + priceSorting;
    }
  }

  useEffect(() => {
    // Let's hit the REST API
    // REST API URL? http://localhost:3000/products
    // Http Method GET
    // REST API client? axios
    axios
      .get(API_URL)
      .then((response) => {
        setProductsList(response.data);
        setIsLoaded(true);
      })
      .catch(() => {
        setIsError(true);
        setIsLoaded(true);
      })
      .finally(() => {});
  }, [API_URL]);

  return (
    <>
      {/* Page Title and Description */}
      <Helmet>
        <title>Product Page Implementation</title>
        <meta
          name="description"
          content="Design a page by listing Products available under clothing. Expected output is given as sample"
        />
      </Helmet>
      <div className='row'>
        <div className='col'>
          <h2>Products</h2>
        </div>
      </div>
      <div className="row">
        {/* Side Bar */}
        <div className="col-4">
          <SideBar
            setSelectedValue={setSelectedValue}
            setPriceSorting={setPriceSorting}
          />
        </div>

        {/* Products Section */}
        <div className="col-8 mt-3">
          {!isLoaded && <Loader />}
          {isError && <Error />}
          {isLoaded && !isError && (
            <div className="row">
              <div className="col-6">
                {' '}
                <h3 className="gl-text-green mb-3 mt-3">
                  {productsList.length} Products Found
                </h3>
              </div>
              <div className="col-6">
                <PriceFilter
                  selectedValue={selectedValue}
                  setSelectedValue={setSelectedValue}
                  setPriceSorting={setPriceSorting}
                />
              </div>
            </div>
          )}
          <div className="mt-3 mb-3">
            {isLoaded && <Products productsList={productsList} />}
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductsPage;
