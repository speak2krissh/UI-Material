// Imports from Node Modules
import axios from 'axios';
import { PropTypes } from 'prop-types';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';

// Custom Imports
import getBaseurl from './../../../utilities/getBaseUrl';
import Loader from '../../../components/Loader/Loader';
import Error from '../../../components/Error/Error';

const SideBar = ({ setSelectedValue, setPriceSorting }) => {
  // Should show loader
  // Should display success message
  // Should display error message
  const [categoryList, setcategoryList] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isError, setIsError] = useState(false);
  useEffect(() => {
    // Let's hit the REST API
    // REST API URL? http://localhost:3000/products
    // Http Method GET
    // REST API client? axios
    axios
      .get(getBaseurl() + 'categories')
      .then((response) => {
        setcategoryList(response.data);
        setIsLoaded(true);
      })
      .catch(() => {
        setIsError(true);
        setIsLoaded(true);
      })
      .finally(() => {
      });
  }, []);

  const handleClick = () => {
    setSelectedValue('');
    setPriceSorting('');
  };

  return (
    <>
      {!isLoaded && <Loader />}
      {isError && <Error />}
      {isLoaded && (
        <div className="side-bar">
          <ul>
            {categoryList?.map((category) => (
              <li className="nav-item" key={category.id}>
                <Link role="listitem"
                  className="nav-link"
                  to={
                    category.name !== 'All'
                      ? `/products?category=${category.name}`
                      : '/products'
                  }
                  onClick={handleClick} data-testid="categrySelectBtn"
                >
                  {category.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
};
SideBar.propTypes = {
  setSelectedValue: PropTypes.func,
  setPriceSorting: PropTypes.func
};

export default SideBar;
