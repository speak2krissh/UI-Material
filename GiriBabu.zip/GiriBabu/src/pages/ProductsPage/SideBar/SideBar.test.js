import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
// import { act } from 'react-dom/test-utils';
import { HelmetProvider } from 'react-helmet-async';
import SideBar from './SideBar';
import axios from 'axios';
// setting up mock for axios
// mocking a module with automocked version when needed
jest.mock('axios');

describe('SideBar', () => {
  // Mocking SideBar Data
  it('[MOCKING]: Fetches Categories ', async () => {
    const mockResponse = {
      data: [
        {
          id: 100,
          name: 'All'
        },
        {
          id: 101,
          name: 'Men'
        },
        {
          id: 102,
          name: 'Women'
        },
        {
          id: 103,
          name: 'Kids'
        }
      ]
    };
    axios.get.mockResolvedValue(mockResponse);
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/products']}>
          <SideBar />
        </MemoryRouter>
      </HelmetProvider>
    );
    const addressElement = await screen.findByText('Women');
    expect(addressElement).toBeInTheDocument();
  });

  // NEGATIVE TEST SPEC == Mocking ERROR Response
  it('[MOCKING]: renders error properly when REST API returns error', async () => {
    const error = 'Sorry! Some Error Occurred. Try again later!';
    axios.get.mockRejectedValue(error);
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/products']}>
          <SideBar />
        </MemoryRouter>
      </HelmetProvider>
    );
    const errorElement = await screen.findByText(
      'Sorry! Some Error Occurred. Try again later!'
    );
    expect(errorElement).toBeInTheDocument();
  });

  // it('has properly reset url when click on category links', async () => {
  //   const mockResponse = {
  //     data: [
  //       {
  //         id: 100,
  //         name: 'All'
  //       },
  //       {
  //         id: 101,
  //         name: 'Men'
  //       },
  //       {
  //         id: 102,
  //         name: 'Women'
  //       },
  //       {
  //         id: 103,
  //         name: 'Kids'
  //       }
  //     ]
  //   };
  //   axios.get.mockResolvedValue(mockResponse);
  //   // act(() => {
  //   render(
  //     <HelmetProvider>
  //       <MemoryRouter>
  //         <SideBar />
  //       </MemoryRouter>
  //     </HelmetProvider>
  //   );
  //   // });

  //   const categorySelectBtn = await screen.getByTestId('categrySelectBtn');
  //   console.log(categorySelectBtn.length);
  //   fireEvent.click(categorySelectBtn);
  // });

  // Testing state value using jest.fn()
  it('Testing Props using jest.fn() ', async () => {
    const setSelectedValueMock = jest.fn();
    const mockResponse = {
      data: [
        { id: 1, name: 'category1' },
        { id: 2, name: 'category2' },
        { id: 3, name: 'category3' },
        { id: 4, name: 'category4' }
      ]
    };
    axios.get.mockResolvedValue(mockResponse);

    render(
      <HelmetProvider>
        <MemoryRouter>
          <SideBar setSelectedValue={setSelectedValueMock} />
        </MemoryRouter>
      </HelmetProvider>
    );

    const categorySelectBtn = screen.findAllByRole('listitem');

    categorySelectBtn.forEach((links) => {
      fireEvent.click(links);
    });

    expect(setSelectedValueMock).toHaveBeenCalledTimes(4);
    expect(setSelectedValueMock).toHaveBeenCalledWith('');
  });
});
