// Imports from Node Modules
import { Route, Routes } from 'react-router-dom';
import React, { Suspense } from 'react';

// Custom Imports
import HomePage from './../pages/HomePage/HomePage';
import ProductsPage from './../pages/ProductsPage/ProductsPage';
import AboutUsPage from './../pages/AboutUsPage/AboutUsPage';
import ContactPage from './../pages/ContactPage/ContactPage';
import ProductsDetailsPage from '../pages/ProductsPage/ProductsDetailsPage/ProductsDetailsPage';
import PageNotFound from './../pages/PageNotFound/PageNotFound';

// the following components are lazy loaded -- also refer suspense
const History = React.lazy(() => import('../pages/AboutUsPage/History/History'));

const AppRoutes = () => {
  return (
    <Suspense fallback={<div className="spinner-border"></div>}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/products/:id" element={<ProductsDetailsPage />} />
        <Route path="/about-us" element={<AboutUsPage />}>
          <Route path="/about-us/history" element={<History />} />
        </Route>
        <Route path="/contact" element={<ContactPage />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </Suspense>
  );
};

export default AppRoutes;
