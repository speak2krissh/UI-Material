import React from 'react';
import { render, screen } from '@testing-library/react';
import { HelmetProvider } from 'react-helmet-async';
import { MemoryRouter } from 'react-router-dom';

// Custom Imports
import AppRoutes from './AppRoutes';

// Testing App Routes...
describe('App Routes', () => {
  // Home Page
  it('should render Home page when path is "/"', () => {
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/']}>
          <AppRoutes />
        </MemoryRouter>
      </HelmetProvider>
    );

    const homePageContent = screen.getByText('FREE SHIPPING & RETURN');
    expect(homePageContent).toBeInTheDocument();
  });

  // Proudcts Page
  it('should render Products page when path is "/products"', () => {
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/products']}>
          <AppRoutes />
        </MemoryRouter>
      </HelmetProvider>
    );

    const productPageContent = screen.getByText('Products');
    expect(productPageContent).toBeInTheDocument();
  });

  // Product Details
  it('should render ProductDetails page when path is "/products/:id"', () => {
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/products/:id']}>
          <AppRoutes />
        </MemoryRouter>
      </HelmetProvider>
    );

    const productDetailsPageContent = screen.getByText('Back To Products Page');
    expect(productDetailsPageContent).toBeInTheDocument();
  });

  // About Us
  it('should render About page when path is "/about-us/"', () => {
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/about-us/']}>
          <AppRoutes />
        </MemoryRouter>
      </HelmetProvider>
    );

    const aboutUsPageContent = screen.getByText('The History');
    expect(aboutUsPageContent).toBeInTheDocument();
  });

  // About Us / History - with Lazy loading
  it('should render About page history when path is "/about-us/history"', async () => {
    render(
      <HelmetProvider>
        <MemoryRouter initialEntries={['/about-us/history']}>
          <AppRoutes />
        </MemoryRouter>
      </HelmetProvider>
    );

    const aboutUsHistoryPageContent = await screen.findByTestId('historyDesc');
    expect(aboutUsHistoryPageContent).toBeInTheDocument();
  });
});
